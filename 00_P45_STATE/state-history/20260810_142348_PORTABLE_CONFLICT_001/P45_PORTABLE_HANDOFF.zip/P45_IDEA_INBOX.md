﻿# P45 IDEA INBOX

APPEND ONLY. 공식 채택 전 연구 아이디어를 보관한다. 현재 확인된 미승인 아이디어는 없다.

## ENTRY TEMPLATE

## IDEA-YYYYMMDD-NNN

- timestamp:
- source:
- title:
- idea:
- reason:
- related_stage:
- related_rule:
- status: PENDING
- official_effect: NONE
- next_review:
- promoted_decision_id:

허용 상태: `PENDING`, `UNDER_REVIEW`, `APPROVED`, `REJECTED`, `SUPERSEDED`.
